// src/main.c

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "../include/process.h"
#include "../include/scheduler.h"

#define MAX_PROCESSES 100

int main(int argc, char* argv[]) {
    int n, quantum;
    Process processes[MAX_PROCESSES];
    Process* loaded_processes = NULL;
    
    // Display system info
    display_system_info();
    
    // Check for file input
    if (argc == 2) {
        printf("Loading processes from file: %s\n", argv[1]);
        n = load_processes_from_file(argv[1], &loaded_processes);
        if (n <= 0) {
            printf("Failed to load from file. Switching to manual input.\n");
            goto manual_input;
        }
        
        // Copy loaded processes to local array
        for (int i = 0; i < n && i < MAX_PROCESSES; i++) {
            processes[i] = loaded_processes[i];
        }
        free(loaded_processes);
        goto algorithm_selection;
    }

manual_input:
    display_menu_header();
    
    // Input validation for number of processes
    do {
        printf("Enter number of processes (1-%d): ", MAX_PROCESSES);
        if (scanf("%d", &n) != 1) {
            printf("Error: Please enter a valid integer!\n");
            while (getchar() != '\n');
            continue;
        }
        
        if (n <= 0 || n > MAX_PROCESSES) {
            printf("Invalid number! Please enter between 1 and %d.\n", MAX_PROCESSES);
        }
    } while (n <= 0 || n > MAX_PROCESSES);

    // Algorithm selection first to determine input requirements
    int choice;
algorithm_selection:
    do {
        printf("\n🎯 SCHEDULING ALGORITHMS MENU 🎯\n");
        printf("=====================================\n");
        printf("1. FCFS (First Come First Served)\n");
        printf("2. SJF (Shortest Job First)\n");
        printf("3. Priority Scheduling\n");
        printf("4. Round Robin (Time Slicing)\n");
        printf("5. SRTF (Shortest Remaining Time First)\n");
        printf("=====================================\n");
        printf("Enter choice (1-5): ");
        
        if (scanf("%d", &choice) != 1) {
            printf("Error: Please enter a valid integer!\n");
            while (getchar() != '\n');
            continue;
        }
        
        if (choice < 1 || choice > 5) {
            printf("Invalid choice! Please enter 1-5.\n");
        }
    } while (choice < 1 || choice > 5);

    // Collect process data based on algorithm choice
    if (argc == 1) { // Only if not loaded from file
        for (int i = 0; i < n; i++) {
            int arrival, burst, priority = 5; // Default priority
            
            do {
                if (choice == 3) { // Priority scheduling needs priority input
                    printf("Enter Arrival, Burst time, and Priority for P%d (Priority: 1=highest, 10=lowest): ", i);
                    if (scanf("%d %d %d", &arrival, &burst, &priority) != 3) {
                        printf("Error: Please enter three valid integers!\n");
                        while (getchar() != '\n');
                        continue;
                    }
                    if (priority < 1 || priority > 10) {
                        printf("Error: Priority must be 1-10. Try again.\n");
                        continue;
                    }
                } else {
                    printf("Enter Arrival and Burst time for P%d: ", i);
                    if (scanf("%d %d", &arrival, &burst) != 2) {
                        printf("Error: Please enter two valid integers!\n");
                        while (getchar() != '\n');
                        continue;
                    }
                }
                
                if (arrival < 0) {
                    printf("Error: Arrival time must be >= 0. Try again.\n");
                    continue;
                }
                if (burst <= 0) {
                    printf("Error: Burst time must be > 0. Try again.\n");
                    continue;
                }
                
                // Valid input
                processes[i].arrival_time = arrival;
                processes[i].burst_time = burst;
                processes[i].priority = priority;
                break;
                
            } while (1);
            
            // Initialize other fields
            processes[i].pid = i;
            processes[i].remaining_time = processes[i].burst_time;
            processes[i].start_time = 0;
            processes[i].completion_time = 0;
            processes[i].turnaround_time = 0;
            processes[i].waiting_time = 0;
            processes[i].response_time = 0;
        }
    }

    // Execute selected algorithm
    printf("\n🚀 Starting %s Algorithm...\n", 
           choice == 1 ? "FCFS" : 
           choice == 2 ? "SJF" :
           choice == 3 ? "Priority" :
           choice == 4 ? "Round Robin" : "SRTF");

    switch (choice) {
        case 1:
            run_fcfs(processes, n);
            break;
        case 2:
            run_sjf(processes, n);
            break;
        case 3:
            run_priority(processes, n);
            break;
        case 4:
            // Quantum validation for Round Robin
            do {
                printf("Enter Quantum Time (> 0): ");
                if (scanf("%d", &quantum) != 1) {
                    printf("Error: Please enter a valid integer!\n");
                    while (getchar() != '\n');
                    continue;
                }
                if (quantum <= 0) {
                    printf("Error: Quantum time must be > 0. Try again.\n");
                }
            } while (quantum <= 0);
            run_rr(processes, n, quantum);
            break;
        case 5:
            run_srtf(processes, n);
            break;
    }

    // Save results option
    char save_choice;
    printf("\nSave results to file? (y/n): ");
    scanf(" %c", &save_choice);
    if (save_choice == 'y' || save_choice == 'Y') {
        char filename[256];
        printf("Enter filename: ");
        scanf("%s", filename);
        
        const char* algorithm_name = choice == 1 ? "FCFS" : 
                                   choice == 2 ? "SJF" :
                                   choice == 3 ? "Priority" :
                                   choice == 4 ? "Round Robin" : "SRTF";
        
        save_results_to_file(filename, processes, n, algorithm_name);
        
        char gantt_file[256];
        snprintf(gantt_file, sizeof(gantt_file), "%s_gantt.txt", filename);
        export_gantt_to_file(gantt_file);
        printf("Results saved to %s and %s\n", filename, gantt_file);
    }

    return 0;
}