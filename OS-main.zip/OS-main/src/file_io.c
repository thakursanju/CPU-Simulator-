#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <errno.h>
#include "../include/process.h"
#include "../include/scheduler.h"

// Load processes from file
int load_processes_from_file(const char* filename, Process** processes) {
    FILE* file = fopen(filename, "r");
    if (!file) {
        fprintf(stderr, "Error: Cannot open file '%s': %s\n", filename, strerror(errno));
        return -1;
    }
    
    int count = 0;
    int capacity = 10;
    *processes = malloc(capacity * sizeof(Process));
    
    if (!*processes) {
        fprintf(stderr, "Error: Memory allocation failed\n");
        fclose(file);
        return -1;
    }
    
    char line[256];
    int line_number = 0;
    
    // Skip header line if present
    if (fgets(line, sizeof(line), file)) {
        line_number++;
        if (strstr(line, "PID") || strstr(line, "#")) {
            // This is a header line, continue to next line
        } else {
            // This is data, rewind and process
            rewind(file);
            line_number = 0;
        }
    }
    
    while (fgets(line, sizeof(line), file)) {
        line_number++;
        
        // Skip comments and empty lines
        if (line[0] == '#' || line[0] == '\n' || line[0] == '\r') {
            continue;
        }
        
        // Expand array if needed
        if (count >= capacity) {
            capacity *= 2;
            Process* temp = realloc(*processes, capacity * sizeof(Process));
            if (!temp) {
                fprintf(stderr, "Error: Memory reallocation failed\n");
                free(*processes);
                fclose(file);
                return -1;
            }
            *processes = temp;
        }
        
        // Parse process data
        Process* p = &(*processes)[count];
        int parsed = sscanf(line, "%d %d %d %d", 
                           &p->pid, &p->arrival_time, &p->burst_time, &p->priority);
        
        if (parsed < 3) {
            fprintf(stderr, "Warning: Invalid format on line %d: %s", line_number, line);
            continue;
        }
        
        // Set default priority if not provided
        if (parsed < 4) {
            p->priority = 5; // Default priority
        }
        
        // Initialize other fields
        p->start_time = 0;
        p->completion_time = 0;
        p->turnaround_time = 0;
        p->waiting_time = 0;
        p->response_time = 0;
        
        count++;
    }
    
    fclose(file);
    
    if (count == 0) {
        fprintf(stderr, "Error: No valid processes found in file '%s'\n", filename);
        free(*processes);
        return -1;
    }
    
    printf("Successfully loaded %d processes from '%s'\n", count, filename);
    return count;
}

// Save results to file
int save_results_to_file(const char* filename, Process* processes, int count, 
                        const char* algorithm) {
    FILE* file = fopen(filename, "w");
    if (!file) {
        fprintf(stderr, "Error: Cannot create file '%s': %s\n", filename, strerror(errno));
        return -1;
    }
    
    // Write header
    fprintf(file, "# CPU Scheduler Simulation Results\n");
    fprintf(file, "# Algorithm: %s\n", algorithm);
    fprintf(file, "# Generated on: %s", ctime(&(time_t){time(NULL)}));
    fprintf(file, "# Format: PID AT BT Priority ST CT TAT WT RT\n");
    fprintf(file, "#\n");
    
    // Write process data
    fprintf(file, "PID\tAT\tBT\tPriority\tST\tCT\tTAT\tWT\tRT\n");
    
    float total_tat = 0, total_wt = 0, total_rt = 0;
    
    for (int i = 0; i < count; i++) {
        fprintf(file, "%d\t%d\t%d\t%d\t\t%d\t%d\t%d\t%d\t%d\n",
                processes[i].pid,
                processes[i].arrival_time,
                processes[i].burst_time,
                processes[i].priority,
                processes[i].start_time,
                processes[i].completion_time,
                processes[i].turnaround_time,
                processes[i].waiting_time,
                processes[i].response_time);
        
        total_tat += processes[i].turnaround_time;
        total_wt += processes[i].waiting_time;
        total_rt += processes[i].response_time;
    }
    
    // Write summary statistics
    fprintf(file, "\n# Summary Statistics\n");
    fprintf(file, "Average Turnaround Time: %.2f\n", total_tat / count);
    fprintf(file, "Average Waiting Time: %.2f\n", total_wt / count);
    fprintf(file, "Average Response Time: %.2f\n", total_rt / count);
    
    fclose(file);
    printf("Results saved to '%s'\n", filename);
    return 0;
}

// Load configuration from file
int load_config_from_file(const char* filename, int* time_quantum) {
    FILE* file = fopen(filename, "r");
    if (!file) {
        fprintf(stderr, "Warning: Cannot open config file '%s': %s\n", 
                filename, strerror(errno));
        fprintf(stderr, "Using default configuration\n");
        return -1;
    }
    
    char line[256];
    while (fgets(line, sizeof(line), file)) {
        // Skip comments and empty lines
        if (line[0] == '#' || line[0] == '\n' || line[0] == '\r') {
            continue;
        }
        
        // Parse configuration
        if (strncmp(line, "time_quantum=", 13) == 0) {
            *time_quantum = atoi(line + 13);
        }
    }
    
    fclose(file);
    printf("Configuration loaded from '%s'\n", filename);
    printf("Time quantum: %d\n", *time_quantum);
    return 0;
}

// Generate sample test cases
int generate_sample_processes(const char* filename, int count) {
    FILE* file = fopen(filename, "w");
    if (!file) {
        fprintf(stderr, "Error: Cannot create file '%s': %s\n", filename, strerror(errno));
        return -1;
    }
    
    // Write header
    fprintf(file, "# Sample Process Data\n");
    fprintf(file, "# Format: PID ArrivalTime BurstTime Priority\n");
    fprintf(file, "# Priority: Lower number = Higher priority\n");
    fprintf(file, "#\n");
    
    srand(time(NULL));
    
    for (int i = 0; i < count; i++) {
        int pid = i;
        int arrival_time = rand() % 10; // 0-9
        int burst_time = 1 + rand() % 10; // 1-10
        int priority = 1 + rand() % 5; // 1-5
        
        fprintf(file, "%d %d %d %d\n", pid, arrival_time, burst_time, priority);
    }
    
    fclose(file);
    printf("Generated %d sample processes in '%s'\n", count, filename);
    return 0;
}

// Display file format help
void display_file_format_help() {
    printf("\n=== File Format Help ===\n");
    printf("Input file format (space or tab separated):\n");
    printf("PID ArrivalTime BurstTime Priority\n");
    printf("0   0           5         2\n");
    printf("1   1           3         1\n");
    printf("2   2           8         3\n");
    printf("\nExample file content:\n");
    printf("# This is a comment\n");
    printf("# PID AT BT Priority\n");
    printf("0 0 5 2\n");
    printf("1 1 3 1\n");
    printf("2 2 8 3\n");
    printf("\nNotes:\n");
    printf("- Lines starting with # are comments\n");
    printf("- Priority is optional (default = 5)\n");
    printf("- Lower priority number = Higher priority\n");
    printf("========================\n\n");
}

// Interactive file creation
int create_process_file_interactively(const char* filename) {
    FILE* file = fopen(filename, "w");
    if (!file) {
        fprintf(stderr, "Error: Cannot create file '%s': %s\n", filename, strerror(errno));
        return -1;
    }
    
    int count;
    printf("How many processes do you want to create? ");
    if (scanf("%d", &count) != 1 || count <= 0) {
        fprintf(stderr, "Error: Invalid number of processes\n");
        fclose(file);
        return -1;
    }
    
    // Write header
    fprintf(file, "# Process data created interactively\n");
    fprintf(file, "# Format: PID ArrivalTime BurstTime Priority\n");
    fprintf(file, "#\n");
    
    for (int i = 0; i < count; i++) {
        int pid, arrival, burst, priority;
        
        printf("\nProcess %d:\n", i);
        printf("PID (default %d): ", i);
        if (scanf("%d", &pid) != 1) {
            pid = i;
        }
        
        printf("Arrival Time: ");
        if (scanf("%d", &arrival) != 1 || arrival < 0) {
            fprintf(stderr, "Error: Invalid arrival time\n");
            fclose(file);
            return -1;
        }
        
        printf("Burst Time: ");
        if (scanf("%d", &burst) != 1 || burst <= 0) {
            fprintf(stderr, "Error: Invalid burst time\n");
            fclose(file);
            return -1;
        }
        
        printf("Priority (1-10, lower=higher priority): ");
        if (scanf("%d", &priority) != 1 || priority < 1 || priority > 10) {
            priority = 5; // Default priority
        }
        
        fprintf(file, "%d %d %d %d\n", pid, arrival, burst, priority);
    }
    
    fclose(file);
    printf("\nProcess file '%s' created successfully with %d processes\n", filename, count);
    return count;
}

// Export Gantt chart to file (declared in scheduler.h)
void export_gantt_to_file(const char* filename) {
    FILE* file = fopen(filename, "w");
    if (!file) {
        fprintf(stderr, "Error: Cannot create Gantt chart file '%s': %s\n", 
                filename, strerror(errno));
        return;
    }
    
    fprintf(file, "# Gantt Chart Export\n");
    fprintf(file, "# Generated on: %s", ctime(&(time_t){time(NULL)}));
    fprintf(file, "# Format: ProcessID StartTime EndTime\n");
    fprintf(file, "#\n");
    
    // Note: This would need access to the gantt_chart data
    // For now, we'll create a placeholder implementation
    fprintf(file, "# Gantt chart data would be exported here\n");
    fprintf(file, "# This feature requires integration with metrics.c\n");
    
    fclose(file);
    printf("Gantt chart exported to '%s'\n", filename);
}
