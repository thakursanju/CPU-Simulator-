// src/fcfs.c

#include <stdio.h>
#include <unistd.h>
#include <sys/wait.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include "../include/process.h"
#include "../include/scheduler.h"

void run_fcfs(Process* processes, int count) {
    printf("\n=== FCFS (First Come First Served) Execution ===\n");
    
    reset_gantt_chart();
    int current_time = 0;

    for (int i = 0; i < count; i++) {
        // Handle arrival time and CPU idle periods
        if (current_time < processes[i].arrival_time) {
            int idle_time = processes[i].arrival_time - current_time;
            printf("CPU idle from time %d to %d (%d units)\n", 
                   current_time, processes[i].arrival_time, idle_time);
            add_gantt_entry(-1, current_time, processes[i].arrival_time); // -1 for idle
            current_time = processes[i].arrival_time;
        }
        
        processes[i].start_time = current_time;
        
        // Add to Gantt chart
        add_gantt_entry(processes[i].pid, current_time, current_time + processes[i].burst_time);
        
        pid_t pid = fork();
        
        if (pid == -1) {
            // Fork failed
            fprintf(stderr, "Error: Fork failed for process P%d: %s\n", 
                    processes[i].pid, strerror(errno));
            exit(1);
        }

        if (pid == 0) {
            // Child process
            printf("Process P%d started at time %d (PID: %d)\n", 
                   processes[i].pid, current_time, getpid());
            sleep(processes[i].burst_time);
            printf("Process P%d finished at time %d\n", 
                   processes[i].pid, current_time + processes[i].burst_time);
            exit(0);
        } else {
            // Parent process
            int status;
            pid_t result = waitpid(pid, &status, 0);
            if (result == -1) {
                fprintf(stderr, "Error: Wait failed for process P%d: %s\n", 
                        processes[i].pid, strerror(errno));
            }
            
            current_time += processes[i].burst_time;
            processes[i].completion_time = current_time;
            printf("Process P%d completed successfully\n", processes[i].pid);
        }
    }
    
    printf("=== All FCFS processes completed ===\n");
    
    // Display results
    print_gantt_chart();
    calculate_metrics(processes, count);
}