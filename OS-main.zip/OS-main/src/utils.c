#include <stdio.h>
#include "../include/process.h"

// Utility functions can be added here as needed
// Note: Gantt chart and metrics functions are now in metrics.c
