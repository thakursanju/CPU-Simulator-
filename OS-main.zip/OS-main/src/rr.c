// src/rr.c

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
#include <signal.h>
#include <time.h>
#include <errno.h>
#include <string.h>
#include "../include/process.h"
#include "../include/scheduler.h"

void run_rr(Process* processes, int count, int quantum) {
    printf("\n=== Round Robin Execution (Quantum: %d) ===\n", quantum);
    
    reset_gantt_chart();
    int current_time = 0;
    int completed = 0;
    int context_switches = 0;
    
    // Initialize start times and track first execution
    int first_execution[count];
    for (int i = 0; i < count; i++) {
        first_execution[i] = 1;
        processes[i].start_time = -1;
    }

    pid_t pids[count];

    // Fork all processes with error checking
    for (int i = 0; i < count; i++) {
        pids[i] = fork();
        
        if (pids[i] == -1) {
            fprintf(stderr, "Error: Fork failed for process P%d: %s\n", 
                    i, strerror(errno));
            // Cleanup already created processes
            for (int j = 0; j < i; j++) {
                kill(pids[j], SIGTERM);
                waitpid(pids[j], NULL, 0);
            }
            exit(1);
        }

        if (pids[i] == 0) {
            while (1) pause();  // Child waits for signals
        }
    }

    // Round Robin scheduling
    while (completed < count) {
        int process_executed = 0;
        
        for (int i = 0; i < count; i++) {
            if (processes[i].remaining_time <= 0) continue;
            
            // Check if process has arrived
            if (current_time < processes[i].arrival_time) continue;
            
            process_executed = 1;
            context_switches++;
            
            // Set start time for first execution
            if (first_execution[i]) {
                processes[i].start_time = current_time;
                first_execution[i] = 0;
            }

            // Calculate actual execution time
            int exec_time = (processes[i].remaining_time < quantum) ? 
                           processes[i].remaining_time : quantum;
            
            // Add to Gantt chart
            add_gantt_entry(processes[i].pid, current_time, current_time + exec_time);
            
            printf("Process P%d executing from time %d to %d\n", 
                   processes[i].pid, current_time, current_time + exec_time);

            // Resume process
            if (kill(pids[i], SIGCONT) == -1) {
                fprintf(stderr, "Error: Failed to resume process P%d: %s\n", 
                        i, strerror(errno));
            }
            
            sleep(exec_time);
            processes[i].remaining_time -= exec_time;
            current_time += exec_time;

            if (processes[i].remaining_time <= 0) {
                // Process completed
                if (kill(pids[i], SIGTERM) == -1) {
                    fprintf(stderr, "Warning: Failed to terminate process P%d: %s\n", 
                            i, strerror(errno));
                }
                waitpid(pids[i], NULL, 0);
                processes[i].completion_time = current_time;
                completed++;
                printf("Process P%d completed at time %d\n", processes[i].pid, current_time);
            } else {
                // Process needs more time - pause it
                if (kill(pids[i], SIGSTOP) == -1) {
                    fprintf(stderr, "Warning: Failed to pause process P%d: %s\n", 
                            i, strerror(errno));
                }
                printf("Process P%d paused, remaining: %d\n", 
                       processes[i].pid, processes[i].remaining_time);
            }
        }
        
        // Handle CPU idle time
        if (!process_executed) {
            int next_arrival = -1;
            for (int i = 0; i < count; i++) {
                if (processes[i].remaining_time > 0 && 
                    (next_arrival == -1 || processes[i].arrival_time < next_arrival)) {
                    next_arrival = processes[i].arrival_time;
                }
            }
            if (next_arrival > current_time) {
                int idle_time = next_arrival - current_time;
                printf("CPU idle from time %d to %d (%d units)\n", 
                       current_time, next_arrival, idle_time);
                add_gantt_entry(-1, current_time, next_arrival); // -1 for idle
                current_time = next_arrival;
            }
        }
    }
    
    printf("=== All Round Robin processes completed ===\n");
    printf("Total context switches: %d\n", context_switches);
    
    // Display results
    print_gantt_chart();
    calculate_metrics(processes, count);
}