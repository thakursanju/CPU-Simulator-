#include <stdio.h>
#include <stdlib.h>
#include "../include/process.h"

#define MAX_GANTT_ENTRIES 1000

// ANSI Color codes
#define RESET   "\033[0m"
#define RED     "\033[31m"
#define GREEN   "\033[32m"
#define YELLOW  "\033[33m"
#define BLUE    "\033[34m"
#define MAGENTA "\033[35m"
#define CYAN    "\033[36m"
#define WHITE   "\033[37m"
#define GRAY    "\033[90m"

static GanttEntry gantt_chart[MAX_GANTT_ENTRIES];
static int gantt_count = 0;

void reset_gantt_chart() {
    gantt_count = 0;
}

void add_gantt_entry(int process_id, int start_time, int end_time) {
    if (gantt_count < MAX_GANTT_ENTRIES) {
        gantt_chart[gantt_count].process_id = process_id;
        gantt_chart[gantt_count].start_time = start_time;
        gantt_chart[gantt_count].end_time = end_time;
        gantt_count++;
    }
}

void print_gantt_chart() {
    if (gantt_count == 0) {
        printf("No Gantt chart data available.\n");
        return;
    }

    printf("\n" CYAN "=================== ENHANCED GANTT CHART ===================" RESET "\n");
    
    // Calculate total time and idle time
    int total_time = 0;
    int total_idle = 0;
    int context_switches = 0;
    
    for (int i = 0; i < gantt_count; i++) {
        if (gantt_chart[i].end_time > total_time) {
            total_time = gantt_chart[i].end_time;
        }
        if (gantt_chart[i].process_id == -1) {
            total_idle += gantt_chart[i].end_time - gantt_chart[i].start_time;
        }
        if (i > 0 && gantt_chart[i].process_id != gantt_chart[i-1].process_id) {
            context_switches++;
        }
    }
    
    // Print process execution bar with colors
    printf("Timeline: ");
    for (int i = 0; i < gantt_count; i++) {
        int width = gantt_chart[i].end_time - gantt_chart[i].start_time;
        if (width < 2) width = 2;
        
        if (gantt_chart[i].process_id == -1) {
            // Idle time in gray
            printf(GRAY "|%*s" RESET, width-1, "IDLE");
        } else {
            // Process with different colors
            const char* colors[] = {GREEN, YELLOW, BLUE, MAGENTA, CYAN, RED};
            const char* color = colors[gantt_chart[i].process_id % 6];
            printf("%s| P%-*d" RESET, color, width-2, gantt_chart[i].process_id);
        }
        
        // Add context switch marker
        if (i < gantt_count - 1 && gantt_chart[i].process_id != gantt_chart[i+1].process_id) {
            printf(RED "|" RESET);
        } else {
            printf("|");
        }
    }
    printf("\n");
    
    // Print timeline numbers
    printf("Time:     ");
    printf("%-2d", gantt_chart[0].start_time);
    for (int i = 0; i < gantt_count; i++) {
        int width = gantt_chart[i].end_time - gantt_chart[i].start_time;
        if (width < 2) width = 2;
        
        for (int j = 0; j < width; j++) {
            printf(" ");
        }
        printf("%-2d", gantt_chart[i].end_time);
    }
    printf("\n");
    
    // Print legend and statistics
    printf("\n" YELLOW "Legend:" RESET "\n");
    printf(GREEN "P0" RESET "/" YELLOW "P1" RESET "/" BLUE "P2" RESET "... = Process execution\n");
    printf(GRAY "IDLE" RESET " = CPU idle time\n");
    printf(RED "|" RESET " = Context switch\n");
    
    printf("\n" CYAN "Timeline Statistics:" RESET "\n");
    printf("Total execution time: %d units\n", total_time);
    printf("Total idle time: %d units (%.1f%%)\n", 
           total_idle, total_time > 0 ? (float)total_idle/total_time*100 : 0);
    printf("CPU utilization: %.1f%%\n", 
           total_time > 0 ? (float)(total_time-total_idle)/total_time*100 : 0);
    printf("Context switches: %d\n", context_switches);
    
    printf(CYAN "=========================================================" RESET "\n\n");
}

void calculate_metrics(Process* processes, int n) {
    float total_turnaround = 0, total_waiting = 0, total_response = 0;
    
    printf(CYAN "=================== PROCESS METRICS ===================" RESET "\n");
    printf("PID\tAT\tBT\tST\tCT\tTAT\tWT\tRT\n");
    printf("---\t--\t--\t--\t--\t---\t--\t--\n");
    
    for (int i = 0; i < n; i++) {
        // Calculate metrics
        processes[i].turnaround_time = processes[i].completion_time - processes[i].arrival_time;
        processes[i].waiting_time = processes[i].turnaround_time - processes[i].burst_time;
        processes[i].response_time = processes[i].start_time - processes[i].arrival_time;
        
        // Accumulate totals
        total_turnaround += processes[i].turnaround_time;
        total_waiting += processes[i].waiting_time;
        total_response += processes[i].response_time;
        
        // Color code based on performance
        const char* color = processes[i].waiting_time <= 2 ? GREEN : 
                           processes[i].waiting_time <= 5 ? YELLOW : RED;
        
        printf("%sP%d\t%d\t%d\t%d\t%d\t%d\t%d\t%d" RESET "\n",
               color,
               processes[i].pid,
               processes[i].arrival_time,
               processes[i].burst_time,
               processes[i].start_time,
               processes[i].completion_time,
               processes[i].turnaround_time,
               processes[i].waiting_time,
               processes[i].response_time);
    }
    
    printf("\n" YELLOW "================= AVERAGE METRICS =================" RESET "\n");
    printf("Average Turnaround Time: " GREEN "%.2f" RESET "\n", total_turnaround / n);
    printf("Average Waiting Time: " GREEN "%.2f" RESET "\n", total_waiting / n);
    printf("Average Response Time: " GREEN "%.2f" RESET "\n", total_response / n);
    
    // Calculate CPU utilization
    int total_time = 0;
    for (int i = 0; i < n; i++) {
        if (processes[i].completion_time > total_time) {
            total_time = processes[i].completion_time;
        }
    }
    
    int total_burst = 0;
    for (int i = 0; i < n; i++) {
        total_burst += processes[i].burst_time;
    }
    
    printf("CPU Utilization: " GREEN "%.2f%%" RESET "\n", (float)total_burst / total_time * 100);
    printf("Throughput: " GREEN "%.2f" RESET " processes/unit time\n", (float)n / total_time);
    printf(CYAN "===================================================" RESET "\n\n");
}

// Real-time display functions
void display_real_time_status(Process* processes, int count, int current_time, int running_process) {
    // Clear screen (ANSI escape codes)
    printf("\033[2J\033[H");
    
    printf(CYAN "============= REAL-TIME CPU SCHEDULER STATUS =============" RESET "\n");
    printf("Current Time: " GREEN "%d" RESET " units\n", current_time);
    
    if (running_process >= 0) {
        printf("Currently Running: " YELLOW "P%d" RESET " (Priority: %d)\n", 
               processes[running_process].pid, processes[running_process].priority);
    } else {
        printf("Currently Running: " GRAY "CPU IDLE" RESET "\n");
    }
    
    printf("\nProcess Status:\n");
    printf("PID\tStatus\t\tAT\tBT\tRemaining\tPriority\n");
    printf("---\t------\t\t--\t--\t---------\t--------\n");
    
    for (int i = 0; i < count; i++) {
        const char* status;
        const char* color;
        
        if (processes[i].completion_time > 0) {
            status = "COMPLETED";
            color = GREEN;
        } else if (i == running_process) {
            status = "RUNNING";
            color = YELLOW;
        } else if (processes[i].arrival_time <= current_time) {
            status = "READY";
            color = CYAN;
        } else {
            status = "WAITING";
            color = GRAY;
        }
        
        int remaining = processes[i].burst_time;
        if (processes[i].start_time > 0 && processes[i].completion_time == 0) {
            remaining = processes[i].burst_time - (current_time - processes[i].start_time);
            if (remaining < 0) remaining = 0;
        }
        
        printf("%sP%d\t%-12s\t%d\t%d\t%d\t\t%d" RESET "\n",
               color, processes[i].pid, status,
               processes[i].arrival_time, processes[i].burst_time,
               remaining, processes[i].priority);
    }
    
    // Display mini Gantt chart for recent history
    printf("\nRecent Execution History:\n");
    int start_time = current_time - 10;
    if (start_time < 0) start_time = 0;
    
    printf("Time: ");
    for (int t = start_time; t <= current_time; t++) {
        printf("%2d ", t);
    }
    printf("\n");
    
    printf("Exec: ");
    for (int t = start_time; t <= current_time; t++) {
        if (t == current_time && running_process >= 0) {
            printf("%sP%d" RESET " ", YELLOW, processes[running_process].pid);
        } else {
            printf("   ");
        }
    }
    printf("\n");
    
    printf(CYAN "=======================================================" RESET "\n");
}

void show_progress_bar(int completed, int total, const char* label) {
    int bar_width = 30;
    float progress = (float)completed / total;
    int filled = (int)(progress * bar_width);
    
    printf("\r%s [", label);
    for (int i = 0; i < bar_width; i++) {
        if (i < filled) {
            printf(GREEN "█" RESET);
        } else {
            printf(GRAY "░" RESET);
        }
    }
    printf("] %.1f%% (%d/%d)", progress * 100, completed, total);
    fflush(stdout);
}

void display_algorithm_comparison(Process* processes, int count) {
    printf(CYAN "\n============= ALGORITHM PERFORMANCE COMPARISON =============" RESET "\n");
    
    // Save original processes
    Process* original = malloc(count * sizeof(Process));
    if (!original) {
        fprintf(stderr, "Error: Memory allocation failed\n");
        return;
    }
    
    for (int i = 0; i < count; i++) {
        original[i] = processes[i];
    }
    
    printf("Algorithm\t\tAvg TAT\t\tAvg WT\t\tAvg RT\t\tCPU Util\n");
    printf("----------\t\t-------\t\t------\t\t------\t\t--------\n");
    
    // Note: This would require running all algorithms
    // For now, we'll show placeholder data
    printf("FCFS\t\t\t%.2f\t\t%.2f\t\t%.2f\t\t%.1f%%\n", 0.0, 0.0, 0.0, 0.0);
    printf("SJF\t\t\t%.2f\t\t%.2f\t\t%.2f\t\t%.1f%%\n", 0.0, 0.0, 0.0, 0.0);
    printf("Priority\t\t%.2f\t\t%.2f\t\t%.2f\t\t%.1f%%\n", 0.0, 0.0, 0.0, 0.0);
    printf("Round Robin\t\t%.2f\t\t%.2f\t\t%.2f\t\t%.1f%%\n", 0.0, 0.0, 0.0, 0.0);
    printf("SRTF\t\t\t%.2f\t\t%.2f\t\t%.2f\t\t%.1f%%\n", 0.0, 0.0, 0.0, 0.0);
    
    printf(CYAN "=============================================================" RESET "\n");
    
    free(original);
}

void display_system_info() {
    printf(CYAN "\n================= SYSTEM INFORMATION ==================" RESET "\n");
    printf("CPU Scheduler Simulator v2.0\n");
    printf("Real-time process scheduling simulation\n");
    printf("Supported Algorithms:\n");
    printf("  • " GREEN "FCFS" RESET "  - First Come First Served (Non-preemptive)\n");
    printf("  • " GREEN "SJF" RESET "   - Shortest Job First (Non-preemptive)\n");
    printf("  • " GREEN "Priority" RESET " - Priority Scheduling (Non-preemptive)\n");
    printf("  • " GREEN "RR" RESET "    - Round Robin (Preemptive)\n");
    printf("  • " GREEN "SRTF" RESET "  - Shortest Remaining Time First (Preemptive)\n");
    printf("\nFeatures:\n");
    printf("  • Real-time execution visualization\n");
    printf("  • Enhanced Gantt charts with colors\n");
    printf("  • Comprehensive performance metrics\n");
    printf("  • File I/O support for batch processing\n");
    printf("  • Process priority handling\n");
    printf("  • Result export functionality\n");
    printf(CYAN "=======================================================" RESET "\n\n");
}

// Additional utility functions for enhanced visualization
void clear_screen() {
    printf("\033[2J\033[H");
}

void wait_for_enter() {
    printf("\nPress Enter to continue...");
    while (getchar() != '\n');
}

void display_menu_header() {
    clear_screen();
    printf(CYAN "╔══════════════════════════════════════════════════════════════╗\n");
    printf("║              " YELLOW "CPU SCHEDULER SIMULATOR v2.0" CYAN "                 ║\n");
    printf("║                                                              ║\n");
    printf("║    " GREEN "Professional Process Scheduling Simulation System" CYAN "     ║\n");
    printf("╚══════════════════════════════════════════════════════════════╝" RESET "\n\n");
}