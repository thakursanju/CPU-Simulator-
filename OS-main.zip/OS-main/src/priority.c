#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
#include <errno.h>
#include <string.h>
#include "../include/process.h"
#include "../include/scheduler.h"

// Compare function for sorting by priority (lower number = higher priority)
int compare_priority(const void* a, const void* b) {
    Process* p1 = (Process*)a;
    Process* p2 = (Process*)b;
    
    // First sort by arrival time, then by priority
    if (p1->arrival_time != p2->arrival_time) {
        return p1->arrival_time - p2->arrival_time;
    }
    return p1->priority - p2->priority;
}

void run_priority(Process* processes, int count) {
    printf("\n=== Priority Scheduling (Non-Preemptive) Execution ===\n");
    printf("Note: Lower priority number = Higher priority\n");
    
    reset_gantt_chart();
    int current_time = 0;
    int completed = 0;
    int* is_completed = calloc(count, sizeof(int));
    
    if (!is_completed) {
        fprintf(stderr, "Error: Memory allocation failed\n");
        return;
    }
    
    // Display process priorities
    printf("\nProcess Priorities:\n");
    for (int i = 0; i < count; i++) {
        printf("P%d: Priority %d, Burst %d, Arrival %d\n", 
               processes[i].pid, processes[i].priority, 
               processes[i].burst_time, processes[i].arrival_time);
    }
    printf("\n");
    
    while (completed < count) {
        // Find the highest priority process among available processes
        int selected = -1;
        int highest_priority = __INT_MAX__;
        
        for (int i = 0; i < count; i++) {
            if (!is_completed[i] && 
                processes[i].arrival_time <= current_time && 
                processes[i].priority < highest_priority) {
                highest_priority = processes[i].priority;
                selected = i;
            }
        }
        
        if (selected == -1) {
            // No process is ready, find the next arrival
            int next_arrival = __INT_MAX__;
            for (int i = 0; i < count; i++) {
                if (!is_completed[i] && processes[i].arrival_time < next_arrival) {
                    next_arrival = processes[i].arrival_time;
                }
            }
            
            if (next_arrival > current_time) {
                int idle_time = next_arrival - current_time;
                printf("CPU idle from time %d to %d (%d units)\n", 
                       current_time, next_arrival, idle_time);
                add_gantt_entry(-1, current_time, next_arrival);
                current_time = next_arrival;
            }
            continue;
        }
        
        // Execute the selected process
        processes[selected].start_time = current_time;
        add_gantt_entry(processes[selected].pid, current_time, 
                       current_time + processes[selected].burst_time);
        
        pid_t pid = fork();
        
        if (pid == -1) {
            fprintf(stderr, "Error: Fork failed for process P%d: %s\n", 
                    processes[selected].pid, strerror(errno));
            free(is_completed);
            exit(1);
        }
        
        if (pid == 0) {
            // Child process
            printf("Process P%d started at time %d (PID: %d, Priority: %d, Burst: %d)\n", 
                   processes[selected].pid, current_time, getpid(), 
                   processes[selected].priority, processes[selected].burst_time);
            sleep(processes[selected].burst_time);
            printf("Process P%d finished at time %d\n", 
                   processes[selected].pid, current_time + processes[selected].burst_time);
            exit(0);
        } else {
            // Parent process
            int status;
            pid_t result = waitpid(pid, &status, 0);
            
            if (result == -1) {
                fprintf(stderr, "Error: Wait failed for process P%d: %s\n", 
                        processes[selected].pid, strerror(errno));
            }
            
            current_time += processes[selected].burst_time;
            processes[selected].completion_time = current_time;
            is_completed[selected] = 1;
            completed++;
            
            printf("Process P%d completed successfully (Priority: %d, Remaining: %d)\n", 
                   processes[selected].pid, processes[selected].priority, count - completed);
        }
    }
    
    free(is_completed);
    printf("=== All Priority processes completed ===\n");
    
    // Display results
    print_gantt_chart();
    calculate_metrics(processes, count);
}
