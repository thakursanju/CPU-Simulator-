#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
#include <errno.h>
#include <string.h>
#include <signal.h>
#include "../include/process.h"
#include "../include/scheduler.h"

void run_srtf(Process* processes, int count) {
    printf("\n=== SRTF (Shortest Remaining Time First) Preemptive Execution ===\n");
    
    reset_gantt_chart();
    int current_time = 0;
    int completed = 0;
    int* remaining_time = malloc(count * sizeof(int));
    int* is_completed = calloc(count, sizeof(int));
    int* first_execution = calloc(count, sizeof(int));
    
    if (!remaining_time || !is_completed || !first_execution) {
        fprintf(stderr, "Error: Memory allocation failed\n");
        return;
    }
    
    // Initialize remaining times
    for (int i = 0; i < count; i++) {
        remaining_time[i] = processes[i].burst_time;
    }
    
    printf("Starting SRTF simulation with time quantum = 1 unit\n\n");
    
    while (completed < count) {
        // Find the process with shortest remaining time among available processes
        int selected = -1;
        int min_remaining = __INT_MAX__;
        
        for (int i = 0; i < count; i++) {
            if (!is_completed[i] && 
                processes[i].arrival_time <= current_time && 
                remaining_time[i] < min_remaining) {
                min_remaining = remaining_time[i];
                selected = i;
            }
        }
        
        if (selected == -1) {
            // No process is ready, find the next arrival
            int next_arrival = __INT_MAX__;
            for (int i = 0; i < count; i++) {
                if (!is_completed[i] && processes[i].arrival_time < next_arrival) {
                    next_arrival = processes[i].arrival_time;
                }
            }
            
            if (next_arrival > current_time) {
                printf("CPU idle from time %d to %d\n", current_time, next_arrival);
                add_gantt_entry(-1, current_time, next_arrival);
                current_time = next_arrival;
            }
            continue;
        }
        
        // Set start time for first execution
        if (!first_execution[selected]) {
            processes[selected].start_time = current_time;
            first_execution[selected] = 1;
        }
        
        // Execute for 1 time unit (simulated preemption)
        printf("Time %d: Executing P%d (remaining: %d)\n", 
               current_time, processes[selected].pid, remaining_time[selected]);
        
        add_gantt_entry(processes[selected].pid, current_time, current_time + 1);
        
        // Simulate 1 unit of execution
        remaining_time[selected]--;
        current_time++;
        
        // Check if process is completed
        if (remaining_time[selected] == 0) {
            processes[selected].completion_time = current_time;
            is_completed[selected] = 1;
            completed++;
            
            printf("Process P%d completed at time %d\n", 
                   processes[selected].pid, current_time);
        }
        
        // Small delay to show preemptive nature (optional, for demonstration)
        usleep(100000); // 0.1 second delay
    }
    
    free(remaining_time);
    free(is_completed);
    free(first_execution);
    
    printf("=== All SRTF processes completed ===\n");
    
    // Display results
    print_gantt_chart();
    calculate_metrics(processes, count);
}

// Alternative implementation using actual fork/signal for real preemption
void run_srtf_with_signals(Process* processes, int count) {
    printf("\n=== SRTF with Real Process Preemption ===\n");
    printf("Warning: This uses actual signals for preemption\n\n");
    
    reset_gantt_chart();
    int current_time = 0;
    int completed = 0;
    int* remaining_time = malloc(count * sizeof(int));
    int* is_completed = calloc(count, sizeof(int));
    int* process_pids = calloc(count, sizeof(pid_t));
    int* first_execution = calloc(count, sizeof(int));
    
    if (!remaining_time || !is_completed || !process_pids || !first_execution) {
        fprintf(stderr, "Error: Memory allocation failed\n");
        return;
    }
    
    // Initialize remaining times
    for (int i = 0; i < count; i++) {
        remaining_time[i] = processes[i].burst_time;
    }
    
    int current_running = -1;
    
    while (completed < count) {
        // Find the process with shortest remaining time
        int selected = -1;
        int min_remaining = __INT_MAX__;
        
        for (int i = 0; i < count; i++) {
            if (!is_completed[i] && 
                processes[i].arrival_time <= current_time && 
                remaining_time[i] < min_remaining) {
                min_remaining = remaining_time[i];
                selected = i;
            }
        }
        
        if (selected == -1) {
            // CPU idle
            current_time++;
            continue;
        }
        
        // If we need to switch processes
        if (selected != current_running) {
            // Suspend current process if any
            if (current_running != -1 && process_pids[current_running] != 0) {
                kill(process_pids[current_running], SIGSTOP);
                printf("Suspending P%d at time %d\n", 
                       processes[current_running].pid, current_time);
            }
            
            // Start or resume new process
            if (process_pids[selected] == 0) {
                // First time execution
                processes[selected].start_time = current_time;
                first_execution[selected] = 1;
                
                pid_t pid = fork();
                if (pid == 0) {
                    // Child process - execute the job
                    printf("P%d started at time %d\n", processes[selected].pid, current_time);
                    sleep(remaining_time[selected]);
                    exit(0);
                } else {
                    process_pids[selected] = pid;
                }
            } else {
                // Resume existing process
                kill(process_pids[selected], SIGCONT);
                printf("Resuming P%d at time %d\n", processes[selected].pid, current_time);
            }
            
            current_running = selected;
        }
        
        // Execute for 1 time unit
        add_gantt_entry(processes[selected].pid, current_time, current_time + 1);
        remaining_time[selected]--;
        current_time++;
        
        // Check if completed
        if (remaining_time[selected] == 0) {
            processes[selected].completion_time = current_time;
            is_completed[selected] = 1;
            completed++;
            
            // Wait for the process to finish
            if (process_pids[selected] != 0) {
                int status;
                waitpid(process_pids[selected], &status, 0);
                printf("P%d completed at time %d\n", processes[selected].pid, current_time);
            }
            
            current_running = -1;
        }
        
        sleep(1); // 1 second per time unit for demonstration
    }
    
    free(remaining_time);
    free(is_completed);
    free(process_pids);
    free(first_execution);
    
    printf("=== All SRTF processes completed ===\n");
    
    // Display results
    print_gantt_chart();
    calculate_metrics(processes, count);
}
