#ifndef PROCESS_H
#define PROCESS_H

typedef struct {
    int pid;
    int arrival_time;
    int burst_time;
    int remaining_time;
    int start_time;
    int completion_time;
    int turnaround_time;
    int waiting_time;
    int response_time;
    int priority; 
} Process;


typedef struct {
    int process_id;
    int start_time;
    int end_time;
} GanttEntry;

#endif
