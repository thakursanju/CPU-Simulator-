#ifndef SCHEDULER_H
#define SCHEDULER_H

#include "process.h"

// Core scheduling algorithms
void run_fcfs(Process *processes, int n);
void run_rr(Process *processes, int n, int time_quantum);
void run_sjf(Process *processes, int n);
void run_priority(Process *processes, int n);  // Fixed typo
void run_srtf(Process *processes, int n);

// Gantt chart and metrics functions
void reset_gantt_chart();
void add_gantt_entry(int process_id, int start_time, int end_time);
void print_gantt_chart();
void calculate_metrics(Process *processes, int n);

// Real-time display functions
void display_real_time_status(Process* processes, int count, int current_time, int running_process);
void show_progress_bar(int completed, int total, const char* label);
void display_algorithm_comparison(Process* processes, int count);
void display_system_info();
void clear_screen();
void wait_for_enter();
void display_menu_header();

// File I/O functions
int load_processes_from_file(const char* filename, Process** processes);
int save_results_to_file(const char* filename, Process* processes, int count, const char* algorithm);
void export_gantt_to_file(const char* filename);
int load_config_from_file(const char* filename, int* time_quantum);
int generate_sample_processes(const char* filename, int count);
void display_file_format_help();
int create_process_file_interactively(const char* filename);

#endif
